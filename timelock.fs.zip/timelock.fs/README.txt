# timelock.fs
timelock.fs is an extension for the timelock.zone service (https://www.timelock.zone) that enables to encrypt to the future any file and decrypts it using the Windows Explorer.

## Installation
Download Java JDK 17 or higher from any source like: https://jdk.java.net/archive/
Then run install.bat, grant admin permissions (needed to install the Windows extensions) and you are done.

### Installation issues
The Jar timelock.fs.jar has been compiled with Java Runtime Environment (JRE) 17. If the installation does not work it is because you could have an older JRE. In such case, download JRE 17 (see above) and set JAVA_HOME environment variable to point to the new JRE folder.
 
## Usage

### Encrypt to the future
You can right click on any file, e.g. MyFile.pdf, in Windows Explorer, select "Show more options" (this may depend on your Windows version) and then click on "timelock.fs.encrypt".
You will be prompted to choose a date in the future in the format DD/MM/YYYY and an hour. Then you will just have to click on the "Encrypt" button. It will be created a file MyFile.pdf.tlcs that contains the encrypted version of the file MyFile.pdf. You can now delete the original file if you want to hide it.


### Decrypt
The encrypted file is protected until the day before the date you selected.
When the day and hour you selected is reached you can right click on the file, select "Show more options" (this may depend on your Windows version) and then click on "timelock.fs.decrypt". Your file will be decrypted and you will recover the file MyFile.pdf.

## Uninstall
To uninstall the timelock.fs extensions, run uninstall.bat (you must grant admin permissions). 
            